#! /bin/bash
wc -w ???|tr -d 'a-z'

