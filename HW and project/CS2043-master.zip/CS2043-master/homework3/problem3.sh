50 22 * * * ./problem2.sh
