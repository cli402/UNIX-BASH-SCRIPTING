#! /bin/bash
paste -d '\n' yesterday__by__beatles.txt you-i__by__one-direction.txt
