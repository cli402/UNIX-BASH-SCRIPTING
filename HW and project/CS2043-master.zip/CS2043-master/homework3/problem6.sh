#! /bin/bash
mkdir all
find ./cs -type f -exec cp {} ./all \;
