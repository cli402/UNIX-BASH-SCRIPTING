#! /usr/bin/python
# project2a.py

import sys

IN=open(sys.argv[1],'r')
numLines= IN.readlines()
pairList={}
for i in numLines:
  names=i.split(';')[0].strip().split(',')
  for key1 in names:
    pairList.setdefault(key1,{})
    for key2 in names:
      if key1!=key2:
        if pairList[key1].has_key(key2)!=True:
	  pairList[key1][key2]=1 
  
for i in pairList.keys():
  output= i + ":"
  for j in pairList[i].keys():
    output= output + " " + j
  print output + "\n"
	     
  
