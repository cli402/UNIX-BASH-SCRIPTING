#! /usr/bin/python
# project2a.py

import sys

IN=open(sys.argv[2],'r')
numLines= IN.readlines()
pairList={}
for i in numLines:
  names=i.split(';')[0].strip().split(',')
  for key1 in names:
    pairList.setdefault(key1,{})
    for key2 in names:
      if key1!=key2:
        if pairList[key1].has_key(key2)!=True:
	  pairList[key1][key2]=1 
  
#for i in pairList.keys():
 # output= i + ":"
  #for j in pairList[i].keys():
   # output= output + " " + j

queue=[]
record=[]
checkList={}

record.append(sys.argv[1])
checkList[sys.argv[1]]=0
for i in pairList.keys():
  if i==sys.argv[1]:
    for j in pairList[i].keys():
      queue.append(j)
      record.append(j)
      checkList[j]=1
      
while len(queue)!=0:
  sample=queue.pop(0)
  for i in pairList.keys():
    if i==sample:
      for j in pairList[i].keys():
	if checkList.has_key(j)!=True:
	  queue.append(j)
	  record.append(j)
	  checkList[j]=checkList[i]+1

for i in record:
  print i + " " +str(checkList[i])	
