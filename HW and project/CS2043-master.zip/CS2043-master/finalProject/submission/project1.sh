#! /bin/bash

IFS=$'\n'

array1=($(curl http://www.movies.com/rss-feeds/top-ten-box-office-rss 2> /dev/null | grep '<title><![CDATA[[[:digit:]]\+\.'| sed 's/<title><!\[CDATA\[//g' | sed 's/^ *//g' | sed 's/\]\]><\/title>//g'))

array2=($(curl http://www.movies.com/rss-feeds/top-ten-box-office-rss 2> /dev/null | grep '<description><![CDATA[[[:alpha:]]'| sed 's/<description><!\[CDATA\[//g' | sed 's/^ * //g' | sed 's/\]\]><\/description>//g'|tail -10))

while [ 1 -eq 1 ]
do

for i in ${array1[*]}
do
  echo $i
done
echo ""

read -p "Choose a movie (1-10) >" type

case $type in
[1-9])
echo "Movie $type"
echo "Synopsis"
echo ""
echo ${array2[$(($type-1))]}
;;
10)
echo "Movie $type"
echo "Synopsis"
echo ""
echo ${array2[$(($type-1))]}
;;
*)
echo "No synopsis"
;;
esac
echo ""

finalInput=" "
while [ $finalInput != "\n" ]
do
read -p "Press enter to return to the main menu" finalInput
done

clear

done
